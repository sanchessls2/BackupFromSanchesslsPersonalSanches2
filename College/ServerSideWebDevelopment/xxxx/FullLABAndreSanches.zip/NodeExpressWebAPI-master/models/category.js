let category = (categoryId = 0, categoryName,categoryDescription) => {
    this.categoryId = categoryId;
    this.categoryName = categoryName;
    this.categoryDescription = categoryDescription;
}

module.exports = category;